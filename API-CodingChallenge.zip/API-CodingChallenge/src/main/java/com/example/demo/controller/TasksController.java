package com.example.demo.controller;

import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.exception.InternalServerErrorException;
import com.example.demo.exception.ResourceNotFoundException;
import com.example.demo.model.Tasks;
import com.example.demo.repository.TasksRepository;
import com.example.demo.service.TasksService;

@RequestMapping("/api")
@RestController
public class TasksController {

	@Autowired
	  private TasksService tasksService;
	
	@Autowired
	  private TasksRepository tasksRepo;
	  
	  
	  @GetMapping(value="/showTasks")
	  public List<Tasks> showTasks() {
		  return tasksService.showTasks();
	  } 
	  
	  @GetMapping(value="/searchTasks/{id}")
	  public ResponseEntity<Tasks> searchTasks(@PathVariable int id){
		  Tasks tasks = tasksRepo.findById(id)
		       .orElseThrow(() -> new ResourceNotFoundException("Not found Tasks with id = " + id));
		        return new ResponseEntity<>(tasks, HttpStatus.OK);
		  }
	  
	  @PostMapping(value="/addTasks")
	  public String addTasks(@RequestBody Tasks tasks) {
			 long id = tasks.getTaskId();
				String str="";
				str+=id;
				int x = Integer.parseInt(str);
				Tasks tasksFound = tasksRepo.findById(x).orElse(null);
				if (tasksFound!=null) {
					throw new InternalServerErrorException("Alreay Tasks Exists with Id " +x);
				} else {
					tasksRepo.save(tasks);
					return "Doctor Added...";
				}
			}

	  @PutMapping(value="/updateTasks")
	  public void updateTasks(@RequestBody Tasks tasks) {
		  tasksService.updateTasks(tasks);
	  }
	  
	  @DeleteMapping(value="/deleteTasks/{id}")
	  public void deleteTasks(@PathVariable int id) {
		  tasksService.deleteTasks(id);
	  }
	  
	  private Date parseDate(String dateStr) { 
	        try {
	            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
	            java.util.Date utilDate = sdf.parse(dateStr);
	            return new Date(utilDate.getTime());
	        } catch (ParseException e) {
	            return null; 
	        }
	        
	    }
	    
}
