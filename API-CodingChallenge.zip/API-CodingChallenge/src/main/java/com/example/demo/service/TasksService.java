package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import com.example.demo.model.Tasks;
import com.example.demo.repository.TasksRepository;

@Service 
public class TasksService {

	 @Autowired
	  private TasksRepository tasksRepo;
	  
	  @Autowired
	  private JdbcTemplate jdbcTemplate;
	  
	  public List<Tasks> showTasks() {
		  return tasksRepo.findAll();
	  }
	  
	  public Tasks searchTasks(int id) {
		  return tasksRepo.findById(id).get();
	  }
	   
	  public void addTasks(Tasks tasks) {
			tasksRepo.save(tasks);
		}
	  
	  public void updateTasks(Tasks tasks) {
		  tasksRepo.save(tasks);
	  }
	  
	  public void deleteTasks(int id) {
		   tasksRepo.deleteById(id);
	  }
	  	  
}
