package com.example.demo;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import com.example.demo.model.AuthRequest;

class AuthRequestTest {

	@Test
	public void testConstructor() {
		
		AuthRequest authRequest = new AuthRequest();
		assertNotNull(authRequest);
		AuthRequest authRequestNew = new AuthRequest("Soumya", "soumya");
        assertEquals("Soumya", authRequestNew.getUsername());
        assertEquals("soumya", authRequestNew.getPassword());
		}    
	 
	@Test
	public void testGettersAndSetters() {
		
		AuthRequest authRequest = new AuthRequest();
        authRequest.setUsername("Soumya");
        authRequest.setPassword("soumya");

        assertEquals("Soumya", authRequest.getUsername());
        assertEquals("soumya", authRequest.getPassword());
	}
	
} 
