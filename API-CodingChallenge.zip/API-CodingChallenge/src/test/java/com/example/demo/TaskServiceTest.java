package com.example.demo;

import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

import java.util.Date;
import java.util.Arrays;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.scheduling.config.Task;

import com.example.demo.repository.TasksRepository;
import com.example.demo.service.TasksService;
import com.example.demo.model.Tasks;

@SpringBootTest
public class TaskServiceTest {

    @Mock
    private TasksRepository tasksRepo;

    @InjectMocks
    private TasksService tasksService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testshowTasks() {
        Tasks tasks1 = new Tasks(1, "Task 1", "Description 1", new Date(), "HIGH", "PENDING");
        Tasks tasks2 = new Tasks(2, "Task 2", "Description 2", new Date(), "MEDIUM", "IN_PROGRESS");
        
        when(tasksRepo.findAll()).thenReturn(Arrays.asList(tasks1, tasks2));
        
        assertEquals(2, tasksService.showTasks().size());
    }

    @Test
    void testaddTasks() {
        Tasks tasks = new Tasks(1, "Task 1", "Description 1", new Date(), "HIGH", "PENDING");
        
        when(tasksRepo.save(tasks)).thenReturn(tasks);
        
       // assertEquals(tasks, tasksService.addTasks(tasks));
    }

    @Test
    void testupdateTasks() {
    	int id=1;
    	Tasks originalTasks = new Tasks(1, "Original Task", "Original Description", new Date(), "MEDIUM", "PENDING");
        Tasks updatedTasks = new Tasks(1, "Updated Task", "Updated Description", new Date(), "LOW", "COMPLETED");

        
        when(tasksRepo.findById(1)).thenReturn(Optional.of(originalTasks));
        when(tasksRepo.save(updatedTasks)).thenReturn(updatedTasks);

        
      //  Tasks result = tasksService.updateTasks(id, updatedTasks);

        
      //  assertEquals(updatedTasks, result);

        
       // verify(tasksRepo).save(updatedTasks);
    }
 
    @Test
    void testdeleteTasks() {
        int taskId = 1;
        doNothing().when(tasksRepo).deleteById(taskId);
        
        tasksService.deleteTasks(taskId);
        
        verify(tasksRepo, times(1)).deleteById(taskId);
    }
}