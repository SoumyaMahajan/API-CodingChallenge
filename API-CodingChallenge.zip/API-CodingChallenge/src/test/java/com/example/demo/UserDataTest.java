package com.example.demo;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Date;

import org.junit.jupiter.api.Test;

import com.example.demo.model.UserData;

class UserDataTest {


	@Test
	public void testConstructor() {
		
		UserData userData = new UserData();
		assertNotNull(userData);
		UserData userDataNew = new UserData(1, 1, "Raj", "raj@example.com", "raj", "USER");
        assertEquals(1, userDataNew.getUserId());
        assertEquals(1, userDataNew.getTaskId());
        assertEquals("Raj", userDataNew.getName());
        assertEquals("raj@example.com", userDataNew.getEmail());
        assertEquals("raj", userDataNew.getPassword());
        assertEquals("USER", userDataNew.getRole());
		}    
	 
	@Test
	public void testGettersAndSetters() {
		
		UserData userData = new UserData();
        userData.setUserId(2);
        userData.setTaskId(2);
        userData.setName("Rajni");
        userData.setEmail("rajni@example.com");
        userData.setPassword("rajni");
        userData.setRole("ADMIN");

        assertEquals(2, userData.getUserId());
        assertEquals(2, userData.getTaskId());
        assertEquals("Rajni", userData.getName());
        assertEquals("rajni@example.com", userData.getEmail());
        assertEquals("rajni", userData.getPassword());
        assertEquals("ADMIN", userData.getRole());
    }
	
}
