package com.example.demo;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Date;

import org.junit.jupiter.api.Test;

import com.example.demo.model.Tasks;


class TasksTest {

	@Test
	public void testConstructor() {
		
		Tasks tasks = new Tasks();
		assertNotNull(tasks);
		Tasks tasksNew = new Tasks(1, "Bug Fixes", "Resolve the bugs", new Date(), "HIGH", "PENDING");
        assertEquals(1, tasksNew.getTaskId());
        assertEquals("Bug Fixes", tasksNew.getTitle());
        assertEquals("Resolve the bugs", tasksNew.getDescription());
        assertNotNull(tasksNew.getDuedate());
        assertEquals("HIGH", tasksNew.getPriority());
        assertEquals("PENDING", tasksNew.getStatus());
		}   
	 
	@Test
	public void testGettersAndSetters() {
		
		Tasks tasks = new Tasks();
        tasks.setTaskId(2);
        tasks.setTitle("Review Code");
        tasks.setDescription("Review the code");
        tasks.setDuedate(new Date());
        tasks.setPriority("HIGH");
        tasks.setStatus("COMPLETED");

        assertEquals(2, tasks.getTaskId());
        assertEquals("Review Code", tasks.getTitle());
        assertEquals("Review the code", tasks.getDescription());
        assertNotNull(tasks.getDuedate());
        assertEquals("HIGH", tasks.getPriority());
        assertEquals("COMPLETED", tasks.getStatus());
    }
	
}
